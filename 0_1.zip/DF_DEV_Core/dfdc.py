# DertFin Developer Core

# It's Just Help DertFin)))

# Import cmd : import DF_DEV_Core.dfdc

# Import Json And Other Files

import json
import sys
import time
# import datetime
# import os

with open("DF_DEV_Core/DFDC001.json", "r", encoding='utf-8') as dfdc001_file:
    dfdc001_data = json.load(dfdc001_file)

with open("DF_DEV_Core/DFDC002.json", "r", encoding='utf-8') as dfdc002_file:
    dfdc002_data = json.load(dfdc002_file)

with open("DF_DEV_Core/DFDC003.json", "r", encoding='utf-8') as dfdc003_file:
    dfdc003_data = json.load(dfdc003_file)

with open("DF_DEV_Core/CALC.json", "r", encoding='utf-8') as calc_file:
    calc_data = json.load(calc_file)

with open("DF_DEV_Core/MINI_FUNC_SETTINGS.json", "r", encoding='utf-8') as mfs_file:
    mfs_data = json.load(mfs_file)

# Variables From DFDC001

core_version = dfdc001_data['core_version']
core_use_msg = dfdc001_data['core_use_msg']

# Variables From DFDC002

app_version = dfdc002_data['app_version']
app_name = dfdc002_data['app_name']

# Variables From DFDC003

exit_code = dfdc003_data['exit_code']

# Functions


def calc():
    print(calc_data['start_msg'])
    number1 = int(input(calc_data['first_number_msg']))
    number2 = int(input(calc_data['second_number_msg']))
    action = input(calc_data['action']+"("+calc_data['options_for_action']+")? ")
    if action == "+":
        print(calc_data['result_word'], (number1+number2))
    elif action == "-":
        print(calc_data['result_word'], (number1-number2))
    elif action == "*":
        print(calc_data['result_word'], (number1*number2))
    elif action == "/":
        print(calc_data['result_word'], (number1/number2))
    else:
        print(calc_data['wrong_action_msg'])


def exit():
    if mfs_data['exit']['confirmation']:
        exit_confirm = input(mfs_data['exit']['confirm_msg']+"(Yes/No)? ")
        if exit_confirm == "Yes" or exit_confirm == "yes":
            sys.exit(mfs_data['exit']['status'])
        else:
            print(mfs_data['exit']['exit_cancel'])
    else:
        sys.exit(mfs_data['exit']['status'])


def clear():
    print("\n" * mfs_data['clear']['n_count'])


def shutdown(time):
    if mfs_data['shutdown']['use_standart_time']:
        time.sleep(mfs_data['shutdown']['standart_time'])
        sys.exit(mfs_data['shutdown']['exit_status'])
    else:
        time.sleep(time)
        sys.exit(mfs_data['shutdown']['exit_status'])


def check_update():
    print("Check Last Version Here: ",dfdc001_data['update_source_link'])
